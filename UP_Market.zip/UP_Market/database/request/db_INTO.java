package database.request;

import java.sql.*;

public class db_INTO {
    
    public static void main(String[] args) {
        String dbPath = "/home/limon/Dev/Java/UP_Market/database/Shop_E.db";
        String url = "jdbc:sqlite:" + dbPath;
        
        try (Connection conn = DriverManager.getConnection(url)) {
            System.out.println("Соединение с SQLite установлено!");
            populateTables(conn);
        } catch (SQLException e) {
            System.out.println("Ошибка при заполнении базы данных: " + e.getMessage());
        }
    }
    
    private static void populateTables(Connection conn) throws SQLException {
        // Очищаем таблицы перед заполнением (для тестовых целей)
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM orders");
            stmt.execute("DELETE FROM cart_items");
            stmt.execute("DELETE FROM products");
            stmt.execute("DELETE FROM users");
            System.out.println("Таблицы очищены перед заполнением");
        }
        
        // 1. Добавляем тестовых пользователей
        String insertUsers = "INSERT INTO users (username, password, full_name, phone) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertUsers)) {
            // Пользователь 1
            pstmt.setString(1, "limon");
            pstmt.setString(2, "1");
            pstmt.setString(3, "Иванов Иван Иванович");
            pstmt.setString(4, "+79161234567");
            pstmt.executeUpdate();
            
            // Пользователь 2
            pstmt.setString(1, "xz");
            pstmt.setString(2, "12");
            pstmt.setString(3, "Петрова Мария Сергеевна");
            pstmt.setString(4, "+79167654321");
            pstmt.executeUpdate();
            
            System.out.println("Добавлено 2 тестовых пользователя");
        }
        
        // 2. Добавляем тестовые товары
        String insertProducts = "INSERT INTO products (name, description, price, stock_quantity, category, attributes, image_url) " +
                              "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertProducts)) {
            // Ноутбук
            pstmt.setString(1, "Ноутбук ASUS VivoBook 15");
            pstmt.setString(2, "15.6\" FHD, Intel Core i5, 8GB RAM, 512GB SSD");
            pstmt.setDouble(3, 54999.99);
            pstmt.setInt(4, 10);
            pstmt.setString(5, "Ноутбуки");
            pstmt.setString(6, "{\"Процессор\":\"Intel Core i5-1135G7\",\"Оперативная память\":\"8 ГБ\",\"SSD\":\"512 ГБ\",\"Экран\":\"15.6\" FHD\"}");
            pstmt.setString(7, "/home/limon/Dev/Java/UP_Market/Data/VivoBook.jpg");
            pstmt.executeUpdate();
            
            // Смартфон
            pstmt.setString(1, "Смартфон Samsung Galaxy S21");
            pstmt.setString(2, "6.2\" Dynamic AMOLED, 128GB, Phantom Gray");
            pstmt.setDouble(3, 69999.99);
            pstmt.setInt(4, 15);
            pstmt.setString(5, "Смартфоны");
            pstmt.setString(6, "{\"Экран\":\"6.2\" Dynamic AMOLED\",\"Память\":\"128 ГБ\",\"Камеры\":\"Тройная 12+64+12 Мп\",\"Аккумулятор\":\"4000 мАч\"}");
            pstmt.setString(7, "/home/limon/Dev/Java/UP_Market/Data/Samsung_S21.jpg");
            pstmt.executeUpdate();
            
            // Наушники
            pstmt.setString(1, "Наушники Sony WH-1000XM4");
            pstmt.setString(2, "Беспроводные наушники с шумоподавлением");
            pstmt.setDouble(3, 24999.99);
            pstmt.setInt(4, 8);
            pstmt.setString(5, "Аксессуары");
            pstmt.setString(6, "{\"Тип\":\"Накладные\",\"Bluetooth\":\"5.0\",\"Время работы\":\"30 часов\",\"Шумоподавление\":\"Да\"}");
            pstmt.setString(7, "/home/limon/Dev/Java/UP_Market/Data/Sony_WH.jpg");
            pstmt.executeUpdate();
            
            System.out.println("Добавлено 3 тестовых товара");
        }
        
        // 3. Добавляем товары в корзину пользователя
        String insertCartItems = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertCartItems)) {
            // Иванов добавил ноутбук и наушники
            pstmt.setInt(1, 1); // user_id = 1 (Иванов)
            pstmt.setInt(2, 1); // product_id = 1 (Ноутбук)
            pstmt.setInt(3, 1); // количество = 1
            pstmt.executeUpdate();
            
            pstmt.setInt(1, 1);
            pstmt.setInt(2, 3); // product_id = 3 (Наушники)
            pstmt.setInt(3, 2); // количество = 2
            pstmt.executeUpdate();
            
            // Петрова добавила смартфон
            pstmt.setInt(1, 2); // user_id = 2 (Петрова)
            pstmt.setInt(2, 2); // product_id = 2 (Смартфон)
            pstmt.setInt(3, 1); // количество = 1
            pstmt.executeUpdate();
            
            System.out.println("Добавлены товары в корзины пользователей");
        }
        
        // 4. Создаем тестовые заказы
        String insertOrders = "INSERT INTO orders (user_id, total_amount, status, pickup_point, payment_method, payment_status, items) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(insertOrders)) {
            // Заказ Иванова
            pstmt.setInt(1, 1); // user_id = 1 (Иванов)
            pstmt.setDouble(2, 104999.97); // total_amount
            pstmt.setString(3, "completed"); // status
            pstmt.setString(4, "Магазин на Ленинском проспекте, 42"); // pickup_point
            pstmt.setString(5, "credit_card"); // payment_method
            pstmt.setString(6, "paid"); // payment_status
            pstmt.setString(7, "[{\"product_id\":1,\"name\":\"Ноутбук ASUS VivoBook 15\",\"quantity\":1,\"price\":54999.99},"
                    + "{\"product_id\":3,\"name\":\"Наушники Sony WH-1000XM4\",\"quantity\":2,\"price\":24999.99}]");
            pstmt.executeUpdate();
            
            // Заказ Петровой
            pstmt.setInt(1, 2); // user_id = 2 (Петрова)
            pstmt.setDouble(2, 69999.99); // total_amount
            pstmt.setString(3, "pending"); // status
            pstmt.setString(4, "Пункт выдачи на Профсоюзной, 15"); // pickup_point
            pstmt.setString(5, "online_bank"); // payment_method
            pstmt.setString(6, "unpaid"); // payment_status
            pstmt.setString(7, "[{\"product_id\":2,\"name\":\"Смартфон Samsung Galaxy S21\",\"quantity\":1,\"price\":69999.99}]");
            pstmt.executeUpdate();
            
            System.out.println("Добавлено 2 тестовых заказа");
        }
        
        System.out.println("База данных успешно заполнена тестовыми данными!");
    }
}