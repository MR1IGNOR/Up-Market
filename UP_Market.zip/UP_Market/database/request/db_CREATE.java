package database.request;

import java.sql.*;

public class db_CREATE {
    
    public static void main(String[] args) {
        String dbPath = "/home/limon/Dev/Java/UP_Market/database/Shop_E.db";
        String url = "jdbc:sqlite:" + dbPath;
        
        try (Connection conn = DriverManager.getConnection(url)) {
            System.out.println("Соединение с SQLite установлено!");
            createTables(conn);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    private static void createTables(Connection conn) throws SQLException {
        // 1. Таблица пользователей
        String createUsersTable = "CREATE TABLE IF NOT EXISTS users (\n"
                + " user_id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " username VARCHAR(50) NOT NULL UNIQUE,\n"
                + " password VARCHAR(255) NOT NULL,\n"
                + " full_name VARCHAR(100),\n"
                + " phone VARCHAR(20),\n"
                + " registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n"
                + ");";
        
        // 2. Таблица товаров
        String createProductsTable = "CREATE TABLE IF NOT EXISTS products (\n"
                + " product_id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " name VARCHAR(100) NOT NULL,\n"
                + " description TEXT,\n"
                + " price REAL NOT NULL,\n"
                + " stock_quantity INTEGER NOT NULL DEFAULT 0,\n"
                + " category VARCHAR(50) NOT NULL,\n"
                + " attributes TEXT, -- JSON с характеристиками\n"
                + " image_url TEXT,\n"
                + " is_active BOOLEAN DEFAULT 1\n"
                + ");";
        
        // 3. Таблица корзины
        String createCartItemsTable = "CREATE TABLE IF NOT EXISTS cart_items (\n"
                + " cart_item_id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " user_id INTEGER NOT NULL,\n"
                + " product_id INTEGER NOT NULL,\n"
                + " quantity INTEGER NOT NULL DEFAULT 1,\n"
                + " added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n"
                + " FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,\n"
                + " FOREIGN KEY (product_id) REFERENCES products(product_id)\n"
                + ");";
        
        // 4. Таблица заказов
        String createOrdersTable = "CREATE TABLE IF NOT EXISTS orders (\n"
                + " order_id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " user_id INTEGER NOT NULL,\n"
                + " order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n"
                + " total_amount REAL NOT NULL,\n"
                + " status VARCHAR(20) NOT NULL DEFAULT 'pending',\n"
                + " pickup_point TEXT NOT NULL,\n"
                + " payment_method VARCHAR(30),\n"
                + " payment_status VARCHAR(20) DEFAULT 'unpaid',\n"
                + " items TEXT NOT NULL, -- JSON с составом заказа\n"
                + " FOREIGN KEY (user_id) REFERENCES users(user_id)\n"
                + ");";
        
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(createUsersTable);
            stmt.execute(createProductsTable);
            stmt.execute(createCartItemsTable);
            stmt.execute(createOrdersTable);
            System.out.println("Таблицы успешно созданы!");
        }
    }
}