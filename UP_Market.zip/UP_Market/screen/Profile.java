package screen;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import profile.UserInfo;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import database.db;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;

public class Profile extends JPanel {
    // Цвета интерфейса
    private final Color primaryColor = new Color(70, 130, 180);
    private final Color accentColor = new Color(255, 140, 0);
    private final Color backgroundColor = new Color(245, 247, 250);
    private final Color cardColor = Color.WHITE;
    private final Color textColor = new Color(60, 60, 60);
    private final Color lightTextColor = new Color(120, 120, 120);
    private final Color errorColor = new Color(220, 80, 80);

    // Компоненты интерфейса
    private JButton exitBtn;
    private JPanel ordersPanel;
    private CardLayout ordersCardLayout;
    private JPanel ordersCardPanel;

    public Profile(JPanel panelCard, CardLayout cardLayout, UserInfo user) {
        setLayout(new BorderLayout());
        setBackground(backgroundColor);

        UserInfo currentUser = (user != null) ? user : createGuestUser();

        // Настройка карточной компоновки для переключения между профилем и заказами
        ordersCardLayout = new CardLayout();
        ordersCardPanel = new JPanel(ordersCardLayout);
        ordersCardPanel.setBackground(backgroundColor);

        // Панель профиля
        ordersCardPanel.add(createProfilePanel(currentUser, panelCard, cardLayout), "profile");
        // Панель заказов
        ordersCardPanel.add(createOrdersPanel(), "orders");

        // Отображаем профиль по умолчанию
        ordersCardLayout.show(ordersCardPanel, "profile");

        add(ordersCardPanel, BorderLayout.CENTER);
        add(createMenuPanel(panelCard, cardLayout), BorderLayout.SOUTH);
    }

    private JPanel createProfilePanel(UserInfo user, JPanel panelCard, CardLayout cardLayout) {
        JPanel profilePanel = new JPanel(new BorderLayout());
        profilePanel.setBackground(backgroundColor);

        // Верхняя панель с кнопкой выхода
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(backgroundColor);
        topPanel.setBorder(new EmptyBorder(20, 20, 0, 20));

        exitBtn = createStyledButton("Выход", errorColor);
        JPanel exitPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        exitPanel.setBackground(backgroundColor);
        exitPanel.add(exitBtn);
        
        topPanel.add(exitPanel, BorderLayout.EAST);
        profilePanel.add(topPanel, BorderLayout.NORTH);

        // Основное содержимое профиля
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(backgroundColor);

        JPanel infoCard = new JPanel();
        infoCard.setLayout(new BoxLayout(infoCard, BoxLayout.Y_AXIS));
        infoCard.setBackground(cardColor);
        infoCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 1, new Color(220, 220, 220)),
            new EmptyBorder(25, 40, 25, 40)
        ));
        infoCard.setMaximumSize(new Dimension(450, Integer.MAX_VALUE));

        // Заголовок профиля
        JLabel titleLabel = new JLabel("Мой профиль", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(primaryColor);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(new EmptyBorder(0, 0, 15, 0));
        infoCard.add(titleLabel);

        // Информация о пользователе
        addUserInfoField(infoCard, "Логин:", user.getUsername());
        addUserInfoField(infoCard, "ФИО:", user.getFull_name());
        addUserInfoField(infoCard, "Телефон:", user.getPhone());
        addUserInfoField(infoCard, "Дата регистрации:", 
            user.getRegistration_date() != null ? user.getRegistration_date() : 
            new SimpleDateFormat("dd.MM.yyyy").format(new Date()));

        // Кнопка просмотра заказов
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new BoxLayout(buttonsPanel, BoxLayout.Y_AXIS));
        buttonsPanel.setBackground(cardColor);
        buttonsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonsPanel.setMaximumSize(new Dimension(300, 100));
        
        JButton ordersButton = createStyledButton("Мои заказы", accentColor);
        ordersButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        ordersButton.addActionListener(e -> {
            loadUserOrders(user.getUsername());
            ordersCardLayout.show(ordersCardPanel, "orders");
        });
        
        buttonsPanel.add(ordersButton);
        buttonsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        
        infoCard.add(Box.createRigidArea(new Dimension(0, 15)));
        infoCard.add(buttonsPanel);

        // Добавляем карточку информации в центр
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 20, 20, 20);
        centerPanel.add(infoCard, gbc);
        
        profilePanel.add(centerPanel, BorderLayout.CENTER);

        return profilePanel;
    }

    private JPanel createOrdersPanel() {
        JPanel ordersMainPanel = new JPanel(new BorderLayout());
        ordersMainPanel.setBackground(backgroundColor);

        // Панель с кнопкой назад
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(backgroundColor);
        topPanel.setBorder(new EmptyBorder(20, 20, 0, 20));

        JButton backButton = createStyledButton("Назад к профилю", lightTextColor);
        backButton.addActionListener(e -> ordersCardLayout.show(ordersCardPanel, "profile"));

        topPanel.add(backButton, BorderLayout.WEST);
        ordersMainPanel.add(topPanel, BorderLayout.NORTH);

        // Контейнер для списка заказов
        JPanel ordersContainer = new JPanel();
        ordersContainer.setLayout(new BoxLayout(ordersContainer, BoxLayout.Y_AXIS));
        ordersContainer.setBackground(backgroundColor);
        ordersContainer.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(ordersContainer);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        ordersMainPanel.add(scrollPane, BorderLayout.CENTER);
        ordersPanel = ordersMainPanel;

        return ordersMainPanel;
    }

    private JPanel createMenuPanel(JPanel panelCard, CardLayout cardLayout) {
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(primaryColor);
        menuPanel.setBorder(new EmptyBorder(10, 0, 10, 0));
        
        JButton goodsButton = createMenuButton("Товары", false);
        JButton basketButton = createMenuButton("Корзина", false);
        JButton profileButton = createMenuButton("Профиль", true);

        goodsButton.addActionListener(e -> cardLayout.show(panelCard, "goods"));
        basketButton.addActionListener(e -> cardLayout.show(panelCard, "basket"));
        profileButton.addActionListener(e -> cardLayout.show(panelCard, "profile"));

        menuPanel.add(goodsButton);
        menuPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        menuPanel.add(basketButton);
        menuPanel.add(Box.createRigidArea(new Dimension(20, 0)));
        menuPanel.add(profileButton);

        return menuPanel;
    }

    private void loadUserOrders(String username) {
        JPanel ordersContainer = (JPanel)((JScrollPane)ordersPanel.getComponent(1)).getViewport().getView();
        ordersContainer.removeAll();

        if (username.equals("Гость")) {
            showMessage(ordersContainer, "Для просмотра заказов необходимо авторизоваться");
            return;
        }

        try (Connection conn = DriverManager.getConnection(new db().url);
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT order_id, order_date, total_amount, status, items " +
                 "FROM orders WHERE user_id = (SELECT user_id FROM users WHERE username = ?) " +
                 "ORDER BY order_date DESC")) {
            
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            boolean hasOrders = false;
            while (rs.next()) {
                hasOrders = true;
                try {
                    String orderId = rs.getString("order_id");
                    String orderDate = rs.getString("order_date");
                    double totalAmount = rs.getDouble("total_amount");
                    String status = rs.getString("status");
                    String itemsJson = rs.getString("items");

                    // Исправляем JSON перед парсингом
                    String fixedJson = itemsJson.replaceAll("(\\d+),(\\d+)", "$1.$2");
                    
                    JPanel orderPanel = createOrderCard(
                        orderId,
                        formatDate(orderDate),
                        totalAmount,
                        status,
                        new JSONArray(fixedJson)
                    );
                    ordersContainer.add(orderPanel);
                    ordersContainer.add(Box.createRigidArea(new Dimension(0, 15)));
                } catch (Exception e) {
                    System.err.println("Ошибка обработки заказа: " + e.getMessage());
                    ordersContainer.add(createErrorCard("Ошибка загрузки заказа"));
                    ordersContainer.add(Box.createRigidArea(new Dimension(0, 15)));
                }
            }

            if (!hasOrders) {
                showMessage(ordersContainer, "У вас пока нет заказов");
            }
        } catch (SQLException e) {
            System.err.println("Ошибка базы данных: " + e.getMessage());
            showMessage(ordersContainer, "Ошибка при загрузке заказов");
        }

        ordersContainer.revalidate();
        ordersContainer.repaint();
    }

    private JPanel createOrderCard(String orderId, String date, double total, 
                                 String status, JSONArray items) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(cardColor);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 1, new Color(220, 220, 220)),
            new EmptyBorder(15, 20, 15, 20)
        ));
        card.setMaximumSize(new Dimension(Short.MAX_VALUE, 300));

        // Заголовок заказа
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(cardColor);

        JLabel idLabel = new JLabel("Заказ #" + orderId);
        idLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        idLabel.setForeground(primaryColor);

        JLabel dateLabel = new JLabel(date);
        dateLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dateLabel.setForeground(lightTextColor);

        header.add(idLabel, BorderLayout.WEST);
        header.add(dateLabel, BorderLayout.EAST);
        card.add(header);
        card.add(Box.createRigidArea(new Dimension(0, 10)));

        // Информация о заказе
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(cardColor);

        JLabel statusLabel = new JLabel("Статус: " + status);
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        statusLabel.setForeground(accentColor);

        JLabel totalLabel = new JLabel("Сумма: " + String.format("%.2f ₽", total));
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        totalLabel.setForeground(textColor);

        infoPanel.add(statusLabel, BorderLayout.WEST);
        infoPanel.add(totalLabel, BorderLayout.EAST);
        card.add(infoPanel);
        card.add(Box.createRigidArea(new Dimension(0, 15)));

        // Список товаров
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.getJSONObject(i);
            String name = item.getString("name");
            int quantity = item.getInt("quantity");
            double price = item.getDouble("price");

            JPanel itemPanel = new JPanel(new BorderLayout());
            itemPanel.setBackground(cardColor);
            itemPanel.setBorder(new EmptyBorder(5, 0, 5, 0));

            JLabel nameLabel = new JLabel(name);
            nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            nameLabel.setForeground(textColor);

            JLabel detailsLabel = new JLabel(quantity + " × " + String.format("%.2f ₽", price));
            detailsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            detailsLabel.setForeground(lightTextColor);

            itemPanel.add(nameLabel, BorderLayout.WEST);
            itemPanel.add(detailsLabel, BorderLayout.EAST);
            card.add(itemPanel);
        }

        return card;
    }

    // Вспомогательные методы
    private void addUserInfoField(JPanel panel, String label, String value) {
        JPanel field = new JPanel();
        field.setLayout(new BoxLayout(field, BoxLayout.X_AXIS));
        field.setBackground(cardColor);
        field.setAlignmentX(Component.CENTER_ALIGNMENT);
        field.setMaximumSize(new Dimension(400, 25));

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 14)); 
        lbl.setForeground(lightTextColor);
        lbl.setPreferredSize(new Dimension(150, 20));

        JLabel val = new JLabel(value);
        val.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        val.setForeground(textColor);

        field.add(lbl);
        field.add(Box.createRigidArea(new Dimension(10, 0)));
        field.add(val);
        panel.add(field);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setBorder(new EmptyBorder(8, 25, 8, 25));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }

    private JButton createMenuButton(String text, boolean active) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(primaryColor);
        button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
        button.setBorder(new EmptyBorder(5, 15, 5, 15));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
            }
        });
        
        return button;
    }

    private JPanel createErrorCard(String message) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(255, 230, 230));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 1, new Color(220, 180, 180)),
            new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel label = new JLabel(message);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        label.setForeground(errorColor);

        panel.add(label);
        return panel;
    }

    private String formatDate(String dbDate) {
        try {
            SimpleDateFormat dbFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat displayFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            return displayFormat.format(dbFormat.parse(dbDate));
        } catch (Exception e) {
            return dbDate;
        }
    }

    private void showMessage(JPanel container, String message) {
        JLabel label = new JLabel(message, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        label.setForeground(textColor);
        container.add(label);
    }

    private UserInfo createGuestUser() {
        UserInfo guest = new UserInfo();
        guest.username = "Гость";
        guest.full_name = "Не авторизован";
        guest.phone = "Не указан";
        guest.registration_date = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        return guest;
    }

    public JButton getExitButton() {
        return exitBtn;
    }
}