package screen;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import auth.*;
import database.db;
import main.Main;
import profile.UserInfo;

public class Authorization extends JPanel {
    
    public static Entrance log = new Entrance();
    public static Registration reg = new Registration();
    private static UserInfo currentUser = null; 

    public static UserInfo getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(UserInfo user) {
        currentUser = user;
    }

    //----Панель авторизации----\\
    public Authorization(JPanel panelCard, CardLayout cardLayout) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        //----Создание интерфейса----\\
        int fieldWidth = 500;
        int fieldHeight = 50;

        JLabel titleLabel_1 = new JLabel("<html><h1 style='color: #4682B4;'>Вход</h1></html>");
        titleLabel_1.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLabel_2 = new JLabel("<html><h1 style='color: #4682B4;'>Авторизация</h1></html>");
        titleLabel_2.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField _username = new JTextField(25);
        _username.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _username.setFont(new Font("Alena", Font.PLAIN, 20));

        JTextField _password = new JTextField(25);
        _password.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _password.setFont(new Font("Alena", Font.PLAIN, 20));

        JTextField _full_name = new JTextField("Введите ФИО", 25);
        _full_name.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _full_name.setFont(new Font("Alena", Font.PLAIN, 20));

        JTextField _phone = new JTextField("Введите номер(без+)", 25);
        _phone.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _phone.setFont(new Font("Alena", Font.PLAIN, 20));

        JButton _authorization = new JButton("Войти");
        _authorization.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _authorization.setFont(new Font("Alena", Font.PLAIN, 20));

        JButton _registration = new JButton("Зарегистрироваться");
        _registration.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        _registration.setFont(new Font("Alena", Font.PLAIN, 20));

        JButton enterRegistration = new JButton("Подтвердить регистрацию");
        enterRegistration.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        enterRegistration.setFont(new Font("Alena", Font.PLAIN, 20));

        JButton canel = new JButton("Отмена");
        canel.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        canel.setFont(new Font("Alena", Font.PLAIN, 20));

        //----Логика интерфейса----\\
        _authorization.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = _username.getText();
                String password = _password.getText();
                
                db database = new db();
                try (Connection conn = DriverManager.getConnection(database.url);
                    PreparedStatement stmt = conn.prepareStatement(
                        "SELECT * FROM Users WHERE username = ? AND password = ?")) {
                    
                    stmt.setString(1, username);
                    stmt.setString(2, password);
                    ResultSet rs = stmt.executeQuery();
                    
                    if (rs.next()) {
                        UserInfo currentUser = new UserInfo();
                        currentUser.user_id = rs.getInt("user_id");
                        currentUser.username = rs.getString("username");
                        currentUser.full_name = rs.getString("full_name");
                        currentUser.phone = rs.getString("phone");
                        currentUser.registration_date = rs.getString("registration_date");
                        
                        Authorization.setCurrentUser(currentUser);
                        
                        // Обновляем профиль и создаем корзину
                        Main.updateProfilePanel(currentUser);
                        Main.createBasketPanel();
                        
                        cardLayout.show(panelCard, "goods");
                    } else {
                        System.out.println("Неверное имя пользователя или пароль!");
                    }
                } catch (SQLException z) {
                    System.out.println("Ошибка при работе с базой данных: " + z.getMessage());
                }
            } 
        });

        _registration.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("-Работа регистрации");
                _authorization.setVisible(false);
                _registration.setVisible(false);
                titleLabel_1.setVisible(false);
                titleLabel_2.setVisible(true);
                enterRegistration.setVisible(true);
                _full_name.setVisible(true);
                _phone.setVisible(true);
                canel.setVisible(true);
            }     
        });

        enterRegistration.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("-Подтверждение регестрации");
                String username = _username.getText();
                String password = _password.getText();
                String full_name = _full_name.getText();
                String phone = _phone.getText();
                reg.getRegistration(username, password, full_name, phone);
                if (reg.getRegistrationConfirmation()) {
                    _authorization.setVisible(true);
                    _registration.setVisible(true);
                    enterRegistration.setVisible(false);
                    _full_name.setVisible(false);
                    _phone.setVisible(false);
                    canel.setVisible(false);
                }
            }
        });

        canel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("-Работа отмены");
                _authorization.setVisible(true);
                _registration.setVisible(true);
                enterRegistration.setVisible(false);
                _full_name.setVisible(false);
                _phone.setVisible(false);
                canel.setVisible(false);
            }
        });

        //----Добавление интерфейса на панель----\\
        gbc.gridy = 0;
        add(titleLabel_1);
        gbc.gridy = 0;
        titleLabel_2.setVisible(false);
        add(titleLabel_2);
        gbc.gridy = 1;
        add(_username, gbc);
        gbc.gridy = 2;
        add(_password, gbc);
        gbc.gridy = 3;
        _full_name.setVisible(false);
        add(_full_name, gbc);
        gbc.gridy = 4;
        _phone.setVisible(false);
        add(_phone, gbc);
        gbc.gridy = 5;
        add(_authorization, gbc);
        gbc.gridy = 6;
        add(_registration, gbc);
        gbc.gridy = 7;
        enterRegistration.setVisible(false);
        add(enterRegistration, gbc);
        gbc.gridy = 8;
        canel.setVisible(false);
        add(canel, gbc);
    }
}