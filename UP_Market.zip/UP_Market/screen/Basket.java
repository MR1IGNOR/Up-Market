package screen;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import profile.UserInfo;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;

public class Basket extends JPanel {
    private Color primaryColor = new Color(70, 130, 180);
    private Color accentColor = new Color(255, 140, 0);
    private Color backgroundColor = new Color(245, 247, 250);
    private Color cardColor = Color.WHITE;
    private Color textColor = new Color(60, 60, 60);
    
    private List<CartItem> cartItems = new ArrayList<>();
    private DefaultListModel<String> cartListModel = new DefaultListModel<>();
    private JList<String> cartList;
    private JLabel totalLabel;
    private Timer refreshTimer;
    private int currentUserId; // Добавлено объявление переменной

    private String dbPath = "/home/limon/Dev/Java/UP_Market/database/Shop_E.db";

    public Basket(JPanel panelCard, CardLayout cardLayout) {
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        
        UserInfo currentUser = Authorization.getCurrentUser();
        currentUserId = currentUser.user_id;
        
        initUI(panelCard, cardLayout);
        loadCartItems();
        initRefreshTimer();
    }

    private void initRefreshTimer() {
        refreshTimer = new Timer(3000, e -> {
            if (this.isVisible()) {
                loadCartItems();
            }
        });
        refreshTimer.start();
    }

    private void initUI(JPanel panelCard, CardLayout cardLayout) {
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(backgroundColor);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JPanel cartCard = new JPanel();
        cartCard.setLayout(new BoxLayout(cartCard, BoxLayout.Y_AXIS));
        cartCard.setBackground(cardColor);
        cartCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 1, new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(40, 40, 40, 40)));
        cartCard.setMaximumSize(new Dimension(700, Integer.MAX_VALUE));

        JLabel titleLabel = new JLabel("Ваша корзина", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(primaryColor);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        cartCard.add(titleLabel);

        cartList = new JList<>(cartListModel);
        cartList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cartList.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        cartList.setBackground(cardColor);
        cartList.setFixedCellHeight(40);
        cartList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                        boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(
                    list, value, index, isSelected, cellHasFocus);
                label.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
                return label;
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(cartList);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setPreferredSize(new Dimension(600, 300));
        cartCard.add(scrollPane);
        cartCard.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel totalPanel = new JPanel();
        totalPanel.setLayout(new BoxLayout(totalPanel, BoxLayout.X_AXIS));
        totalPanel.setBackground(cardColor);
        totalPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        totalPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        totalLabel = new JLabel("Итого: 0 руб.");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        totalLabel.setForeground(textColor);
        
        totalPanel.add(Box.createHorizontalGlue());
        totalPanel.add(totalLabel);
        totalPanel.add(Box.createHorizontalGlue());
        
        cartCard.add(totalPanel);
        cartCard.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(cardColor);
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton removeButton = createStyledButton("Удалить", new Color(220, 80, 80));
        removeButton.setPreferredSize(new Dimension(150, 45));
        removeButton.addActionListener(e -> removeSelectedItem());
        
        JButton checkoutButton = createStyledButton("Оформить заказ", accentColor);
        checkoutButton.setPreferredSize(new Dimension(200, 45));
        checkoutButton.addActionListener(e -> checkout());
        
        buttonPanel.add(Box.createHorizontalGlue());
        buttonPanel.add(removeButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(30, 0)));
        buttonPanel.add(checkoutButton);
        buttonPanel.add(Box.createHorizontalGlue());
        
        cartCard.add(buttonPanel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(20, 20, 20, 20);
        centerPanel.add(cartCard, gbc);
        
        add(centerPanel, BorderLayout.CENTER);
        add(createMenuPanel(panelCard, cardLayout), BorderLayout.SOUTH);
    }

    private class CartItem {
        int cartItemId;
        int productId;
        String name;
        double price;
        int quantity;
        
        public CartItem(int cartItemId, int productId, String name, double price, int quantity) {
            this.cartItemId = cartItemId;
            this.productId = productId;
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }
        
        @Override
        public String toString() {
            return String.format("%s - %.2f руб. x%d = %.2f руб.", 
                name, price, quantity, price * quantity);
        }
    }

    private void loadCartItems() {

        cartItems.clear();
        cartListModel.clear();
        
        String url = "jdbc:sqlite:" + dbPath;
        String query = "SELECT ci.cart_item_id, ci.product_id, p.name, p.price, ci.quantity " +
                    "FROM cart_items ci " +
                    "JOIN products p ON ci.product_id = p.product_id " +
                    "WHERE ci.user_id = ?";
        
        try (Connection conn = DriverManager.getConnection(url);
            PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, currentUserId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                CartItem item = new CartItem(
                    rs.getInt("cart_item_id"),
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("quantity")
                );
                cartItems.add(item);
                cartListModel.addElement(item.toString());
            }
            
            updateTotal();
        } catch (SQLException e) {
            showError("Ошибка при загрузке корзины: " + e.getMessage());
        }
    }

    private void updateTotal() {
        double total = cartItems.stream()
            .mapToDouble(item -> item.price * item.quantity)
            .sum();
        totalLabel.setText(String.format("Итого: %.2f руб.", total));
    }

    private void removeSelectedItem() {
        int selectedIndex = cartList.getSelectedIndex();
        if (selectedIndex == -1) {
            showWarning("Выберите товар для удаления");
            return;
        }

        CartItem itemToRemove = cartItems.get(selectedIndex);
        String url = "jdbc:sqlite:" + dbPath;
        String query = "DELETE FROM cart_items WHERE cart_item_id = ?";
        
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, itemToRemove.cartItemId);
            if (pstmt.executeUpdate() > 0) {
                cartItems.remove(selectedIndex);
                cartListModel.remove(selectedIndex);
                updateTotal();
                showInfo("Товар удален из корзины");
            }
        } catch (SQLException e) {
            showError("Ошибка при удалении товара: " + e.getMessage());
        }
    }

    private void checkout() {
        if (cartItems.isEmpty()) {
            showError("Корзина пуста!");
            return;
        }
        
        int result = JOptionPane.showConfirmDialog(
            this, 
            "Оформить заказ на сумму " + totalLabel.getText() + "?", 
            "Подтверждение заказа", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (result == JOptionPane.YES_OPTION) {
            createOrder();
            clearCart();
            showInfo("Заказ оформлен успешно!");
        }
    }

    private void createOrder() {

        String url = "jdbc:sqlite:" + dbPath;
        String query = "INSERT INTO orders (user_id, total_amount, status, pickup_point, payment_method, payment_status, items) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, currentUserId);
            pstmt.setDouble(2, calculateTotal());
            pstmt.setString(3, "pending");
            pstmt.setString(4, "Магазин на Ленинском проспекте, 42");
            pstmt.setString(5, "credit_card");
            pstmt.setString(6, "unpaid");
            pstmt.setString(7, buildItemsJson());
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            showError("Ошибка при создании заказа: " + e.getMessage());
        }
    }

    private double calculateTotal() {
        return cartItems.stream()
            .mapToDouble(item -> item.price * item.quantity)
            .sum();
    }

    private String buildItemsJson() {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < cartItems.size(); i++) {
            CartItem item = cartItems.get(i);
            json.append(String.format(
                "{\"product_id\":%d,\"name\":\"%s\",\"quantity\":%d,\"price\":%.2f}",
                item.productId, item.name, item.quantity, item.price));
            
            if (i < cartItems.size() - 1) {
                json.append(",");
            }
        }
        return json.append("]").toString();
    }

    private void clearCart() {

        String url = "jdbc:sqlite:" + dbPath;
        String query = "DELETE FROM cart_items WHERE user_id = ?";
        
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            
            pstmt.setInt(1, currentUserId);
            pstmt.executeUpdate();
            
            cartItems.clear();
            cartListModel.clear();
            updateTotal();
        } catch (SQLException e) {
            showError("Ошибка при очистке корзины: " + e.getMessage());
        }
    }

    private JPanel createMenuPanel(JPanel panelCard, CardLayout cardLayout) {
        JPanel panelMenu = new JPanel();
        panelMenu.setBackground(primaryColor);
        panelMenu.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JButton buttonMenuGoods = createMenuButton("Товары", false);
        JButton buttonMenuBasket = createMenuButton("Корзина", true);
        JButton buttonMenuProfile = createMenuButton("Профиль", false);

        buttonMenuGoods.addActionListener(e -> cardLayout.show(panelCard, "goods"));
        buttonMenuProfile.addActionListener(e -> cardLayout.show(panelCard, "profile"));

        panelMenu.add(Box.createHorizontalGlue());
        panelMenu.add(buttonMenuGoods);
        panelMenu.add(Box.createRigidArea(new Dimension(20, 0)));
        panelMenu.add(buttonMenuBasket);
        panelMenu.add(Box.createRigidArea(new Dimension(20, 0)));
        panelMenu.add(buttonMenuProfile);
        panelMenu.add(Box.createHorizontalGlue());

        return panelMenu;
    }

    private JButton createMenuButton(String text, boolean active) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(primaryColor);
        button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setForeground(Color.WHITE);
            }
            public void mouseExited(MouseEvent evt) {
                button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
            }
        });
        
        return button;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(12, 30, 12, 30));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Ошибка", JOptionPane.ERROR_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Внимание", JOptionPane.WARNING_MESSAGE);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Информация", JOptionPane.INFORMATION_MESSAGE);
    }

    public void stopRefreshTimer() {
        if (refreshTimer != null && refreshTimer.isRunning()) {
            refreshTimer.stop();
        }
    }
    
    public void startRefreshTimer() {
        if (refreshTimer != null && !refreshTimer.isRunning()) {
            refreshTimer.start();
        }
    }
}