package screen;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import goods.Product;
import profile.UserInfo;
import database.db;

public class Goods extends JPanel {
    private Color primaryColor = new Color(70, 130, 180); 
    private Color accentColor = new Color(255, 140, 0); 
    private Color backgroundColor = new Color(245, 247, 250);
    private Color cardColor = Color.WHITE;
    private Color textColor = new Color(60, 60, 60);
    private Color lightTextColor = new Color(120, 120, 120);
    public int isActive = 0;
    
    private JPanel panelProduct;
    private JScrollPane scrollPane;

    public Goods(JPanel panelCard, CardLayout cardLayout) {
        
        this.setLayout(new BorderLayout());
        this.setBackground(backgroundColor);

        JPanel panelSearch = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panelSearch.setBackground(backgroundColor);
        panelSearch.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JTextField searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JButton searchButton = createStyledButton("Поиск", primaryColor);
        searchButton.setPreferredSize(new Dimension(100, 30));
        
        // Добавляем обработчик нажатия кнопки поиска
        searchButton.addActionListener(e -> performSearch(searchField.getText()));
        
        // Добавляем обработчик нажатия Enter в поле поиска
        searchField.addActionListener(e -> performSearch(searchField.getText()));
        
        panelSearch.add(searchField);
        panelSearch.add(searchButton);

        panelProduct = new JPanel();
        panelProduct.setLayout(new BoxLayout(panelProduct, BoxLayout.Y_AXIS));
        panelProduct.setBackground(backgroundColor);
        panelProduct.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        scrollPane = new JScrollPane(panelProduct);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Загружаем все товары при инициализации
        displayProducts(Product.getAllProducts());

        // Нижнее меню
        JPanel panelMenu = new JPanel();
        panelMenu.setBackground(primaryColor);
        panelMenu.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JButton buttonMenuGoods = createMenuButton("Товары", true);
        JButton buttonMenuBasket = createMenuButton("Корзина", false);
        JButton buttonMenuProfile = createMenuButton("Профиль", false);

        buttonMenuBasket.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(panelCard, "basket");
            }
        });

        buttonMenuProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(panelCard, "profile");
            }
        });

        panelMenu.add(buttonMenuGoods);
        panelMenu.add(Box.createRigidArea(new Dimension(20, 0)));
        panelMenu.add(buttonMenuBasket);
        panelMenu.add(Box.createRigidArea(new Dimension(20, 0)));
        panelMenu.add(buttonMenuProfile);

        this.add(panelSearch, BorderLayout.NORTH);
        this.add(scrollPane, BorderLayout.CENTER);
        this.add(panelMenu, BorderLayout.SOUTH);
    }

    // Метод для выполнения поиска
    private void performSearch(String searchText) {
        if (searchText == null || searchText.trim().isEmpty()) {
            // Если поисковый запрос пуст, показываем все товары
            displayProducts(Product.getAllProducts());
            return;
        }
        
        List<Product> allProducts = Product.getAllProducts();
        List<Product> filteredProducts = new ArrayList<>();
        
        String searchLower = searchText.toLowerCase();
        
        for (Product product : allProducts) {
            if (product.isActive() && 
                (product.getName().toLowerCase().contains(searchLower) || 
                 product.getDescription().toLowerCase().contains(searchLower))) {
                filteredProducts.add(product);
            }
        }
        
        displayProducts(filteredProducts);
        
        if (filteredProducts.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Товары по запросу \"" + searchText + "\" не найдены", 
                "Результаты поиска", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Метод для отображения списка товаров
    private void displayProducts(List<Product> products) {
        panelProduct.removeAll();
        
        for (Product product : products) {
            if (product.isActive()) {
                JPanel productPanel = createProductPanel(product);
                panelProduct.add(productPanel);
                panelProduct.add(Box.createRigidArea(new Dimension(0, 15)));
            }
        }
        
        // Добавляем пустое пространство внизу, если товаров мало
        panelProduct.add(Box.createVerticalGlue());
        
        // Обновляем отображение
        panelProduct.revalidate();
        panelProduct.repaint();
        
        // Прокручиваем вверх
        scrollPane.getVerticalScrollBar().setValue(0);
    }

    // Остальные методы класса остаются без изменений
    private JPanel createProductPanel(Product product) {
        JPanel panel = new JPanel(new BorderLayout(15, 0));
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 1, 3, 1, new Color(220, 220, 220)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        panel.setBackground(cardColor);
        panel.setMaximumSize(new Dimension(800, 180));

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBackground(cardColor);

        JLabel nameLabel = new JLabel(product.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        nameLabel.setForeground(textColor);

        JLabel priceLabel = new JLabel("Цена: " + product.getPrice() + " руб.");
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        priceLabel.setForeground(primaryColor);
        priceLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));

        JLabel descLabel = new JLabel("<html><div style='width:450px'>" + product.getDescription() + "</div></html>");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descLabel.setForeground(lightTextColor);

        infoPanel.add(nameLabel);
        infoPanel.add(priceLabel);
        infoPanel.add(descLabel);
        infoPanel.add(Box.createVerticalGlue());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(cardColor);
        
        JButton addToCartButton = createStyledButton("В корзину", accentColor);
        addToCartButton.setPreferredSize(new Dimension(120, 35));

        addToCartButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UserInfo currentUser = Authorization.getCurrentUser();
                if (currentUser == null) {
                    JOptionPane.showMessageDialog(Goods.this, 
                        "Пользователь не авторизован", 
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int currentUserId = currentUser.user_id; 
                
                db database = new db();
                try (Connection conn = DriverManager.getConnection(database.url)) {
                    String checkSql = "SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?";
                    try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                        checkStmt.setInt(1, currentUserId);
                        checkStmt.setInt(2, product.getId());
                        ResultSet rs = checkStmt.executeQuery();
                        
                        if (rs.next()) {
                            int currentQuantity = rs.getInt("quantity");
                            String updateSql = "UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?";
                            try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                                updateStmt.setInt(1, currentQuantity + 1);
                                updateStmt.setInt(2, currentUserId);
                                updateStmt.setInt(3, product.getId());
                                updateStmt.executeUpdate();
                            }
                        } else {
                            String insertSql = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, 1)";
                            try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                                insertStmt.setInt(1, currentUserId);
                                insertStmt.setInt(2, product.getId());
                                insertStmt.executeUpdate();
                            }
                        }
                        
                        JOptionPane.showMessageDialog(Goods.this, 
                            "Товар \"" + product.getName() + "\" добавлен в корзину", 
                            "Успешно", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException z) {
                    System.out.println("Ошибка при работе с базой данных: " + z.getMessage());
                    JOptionPane.showMessageDialog(Goods.this, 
                        "Ошибка при добавлении товара в корзину", 
                        "Ошибка", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        buttonPanel.add(addToCartButton);
        
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(infoPanel, BorderLayout.CENTER);
        rightPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        panel.add(rightPanel, BorderLayout.CENTER);

        return panel;
    }

    private JButton createMenuButton(String text, boolean active) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(primaryColor);
        button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setForeground(active ? Color.WHITE : new Color(220, 220, 220));
            }
        });
        
        return button;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        
        return button;
    }
}