package profile;

import java.sql.*;

import database.db;

public class UserInfo {
    db database = new db();
    public int user_id;
    public String username;
    public String full_name;
    public String phone;
    public String registration_date;

    public int getUser_id() { return user_id; }
    public String getUsername() { return username; }
    public String getFull_name() { return full_name; }
    public String getPhone() { return phone; }
    public String getRegistration_date() { return registration_date; }

    public static UserInfo getUserInfo(String username) {
        db database = new db();
        UserInfo userInfo = new UserInfo();
        
        try (Connection conn = DriverManager.getConnection(database.url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE username = '" + username + "'")) {
            
            if (rs.next()) {
                userInfo.user_id = rs.getInt("user_id");
                userInfo.username = rs.getString("username");
                userInfo.full_name = rs.getString("full_name");
                userInfo.phone = rs.getString("phone");
                userInfo.registration_date = rs.getString("registration_date");
            }
            
        } catch (SQLException e) {
            System.out.println("Ошибка при работе с базой данных: " + e.getMessage());
        }
        
        return userInfo;
    }
}