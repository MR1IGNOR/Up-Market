package auth;
import java.sql.*;

import database.db;

public class Registration {
    private db database = new db();
    String username;
    String password;
    String full_name;
    String phone;
    private boolean registered = false;
    
    public void getRegistration(String username, String password, String full_name, String phone) {
        this.username = username;
        this.password = password;
        this.full_name = full_name;
        this.phone = phone;
        
        String sql = "INSERT INTO users (username, password, full_name, phone) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(database.url);
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // Устанавливаем параметры запроса
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, full_name);
            pstmt.setString(4, phone);
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        registered = true;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Ошибка: " + e.getMessage());
        } 
    }

    public boolean getRegistrationConfirmation() {
        if (registered) {
            System.out.println("-Регистрация успешна!");
        } else {
            System.out.println("-Регистрация провалилась!");
        }
        return registered;
    }

}