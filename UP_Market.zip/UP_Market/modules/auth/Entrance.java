package auth;

import java.sql.*;

import database.db;

public class Entrance {
    
    db database = new db();
    public String username;
    public String password;
    public boolean isAuthenticated = false;

    public void getEntrance(String username, String password) {
        this.username = username;
        this.password = password;

        try (
            Connection conn = DriverManager.getConnection(database.url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM users")
        ) {

            while (rs.next()) {
                String dbUsername = rs.getString("username");
                String dbPassword = rs.getString("password");
                

                if (username.equals(dbUsername) && password.equals(dbPassword)) {
                    isAuthenticated = true;
                    break;
                } else {
                    isAuthenticated = false;
                }
            }
            
        } catch (SQLException e) {
            System.out.println("Ошибка при работе с базой данных: " + e.getMessage());
        }
    }

    public boolean getLoginConfirmation () {
        if (isAuthenticated) {
            System.out.println("-Авторизация выполнена!");
        } else {
            System.out.println("-Авторизация провалилась!");
        }
        return isAuthenticated;
    }
}