package main;

import java.awt.*;
import javax.swing.*;

import screen.*;
import profile.UserInfo;

public class Main {
    public static JFrame rootFrame;
    public static JPanel panelCard;
    public static CardLayout cardLayout;
    public static Authorization panelAuthorization;
    public static Goods panelGoods;
    public static Basket panelBasket;
    public static Profile panelProfile;

    public static void main(String[] args) {
        // Определение разрешения экрана
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        System.out.printf("Разрешение экрана: %dx%d\n", screenSize.width, screenSize.height);
        
        // Параметры окна
        System.out.println("====Запуск GUI====");
        rootFrame = new JFrame("TwoM");
        rootFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        int _windowsWidth = screenSize.width / 2;
        int _windowsHeight = screenSize.height / 2;
        rootFrame.setSize(_windowsWidth, _windowsHeight);

        // Создание контейнера с CardLayout
        cardLayout = new CardLayout();
        panelCard = new JPanel(cardLayout);

        // Создание основных панелей (без корзины)
        panelAuthorization = new Authorization(panelCard, cardLayout);
        panelGoods = new Goods(panelCard, cardLayout);
        panelProfile = new Profile(panelCard, cardLayout, null);
        setupProfileActions();

        // Добавление панелей
        panelCard.add(panelAuthorization, "auth");
        panelCard.add(panelGoods, "goods");
        panelCard.add(panelProfile, "profile");

        // Показываем панель авторизации при старте
        cardLayout.show(panelCard, "auth");

        // Центрирование окна
        rootFrame.setLocation(
            screenSize.width / 2 - (_windowsWidth / 2), 
            screenSize.height / 2 - (_windowsHeight / 2)
        );
        rootFrame.add(panelCard);
        rootFrame.setVisible(true);
    }

    public static void updateProfilePanel(UserInfo user) {
        panelProfile = new Profile(panelCard, cardLayout, user);
        panelCard.add(panelProfile, "profile");
        setupProfileActions();
    }

    public static void createBasketPanel() {
        if (panelBasket == null) {
            panelBasket = new Basket(panelCard, cardLayout);
            panelCard.add(panelBasket, "basket");
        }
    }

    public static void setupProfileActions() {
        if (panelProfile != null) {
            panelProfile.getExitButton().addActionListener(e -> {
                Authorization.setCurrentUser(null);
                cardLayout.show(panelCard, "auth");
                // Можно также очистить корзину при выходе
                panelBasket = null;
            });
        }
    }

    // Геттеры для доступа к компонентам из других классов
    public static JPanel getPanelCard() {
        return panelCard;
    }

    public static CardLayout getCardLayout() {
        return cardLayout;
    }
}