package goods;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import database.db;

public class Product {
    db database = new db();
    private int id;  // Добавляем поле для ID товара
    private String name;
    private String description;
    private String price;
    private String category;
    private String image_url;
    private boolean is_active;

    // Геттеры для доступа к полям
    public int getId() { return id; }  // Добавляем геттер для ID
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getPrice() { return price; }
    public String getCategory() { return category; }
    public String getImage_url() { return image_url; }
    public boolean isActive() { return is_active; }

    // Метод для получения всех товаров из БД
    public static List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        db database = new db();
        
        try (Connection conn = DriverManager.getConnection(database.url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {
            
            while (rs.next()) {
                Product product = new Product();
                product.id = rs.getInt("product_id");  // Получаем ID товара
                product.name = rs.getString("name");
                product.description = rs.getString("description");
                product.price = rs.getString("price");
                product.category = rs.getString("category");
                product.image_url = rs.getString("image_url");
                product.is_active = rs.getBoolean("is_active");
                
                products.add(product);
            }
            
        } catch (SQLException e) {
            System.out.println("Ошибка при работе с базой данных: " + e.getMessage());
        }
        
        return products;
    }
}